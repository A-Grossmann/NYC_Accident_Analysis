var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var lyr_Heatmap_1 = new ol.layer.Image({
                            opacity: 1,
                            title: "Heatmap",
                            
                            
                            source: new ol.source.ImageStatic({
                               url: "./layers/Heatmap_1.png",
    attributions: ' ',
                                projection: 'EPSG:3857',
                                alwaysInRange: true,
                                imageExtent: [-8261520.349477, 4941531.580002, -8203361.258873, 4999709.139538]
                            })
                        });
var format_all_accidents_lon_lat__2 = new ol.format.GeoJSON();
var features_all_accidents_lon_lat__2 = format_all_accidents_lon_lat__2.readFeatures(json_all_accidents_lon_lat__2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_all_accidents_lon_lat__2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_all_accidents_lon_lat__2.addFeatures(features_all_accidents_lon_lat__2);
var lyr_all_accidents_lon_lat__2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_all_accidents_lon_lat__2, 
                style: style_all_accidents_lon_lat__2,
                interactive: false,
                title: '<img src="styles/legend/all_accidents_lon_lat__2.png" /> all_accidents_lon_lat_'
            });
var format_pedestrians_3 = new ol.format.GeoJSON();
var features_pedestrians_3 = format_pedestrians_3.readFeatures(json_pedestrians_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_pedestrians_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_pedestrians_3.addFeatures(features_pedestrians_3);
var lyr_pedestrians_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_pedestrians_3, 
                style: style_pedestrians_3,
                interactive: true,
                title: '<img src="styles/legend/pedestrians_3.png" /> pedestrians'
            });
var format_cyclists_4 = new ol.format.GeoJSON();
var features_cyclists_4 = format_cyclists_4.readFeatures(json_cyclists_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_cyclists_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_cyclists_4.addFeatures(features_cyclists_4);
var lyr_cyclists_4 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_cyclists_4, 
                style: style_cyclists_4,
                interactive: true,
                title: '<img src="styles/legend/cyclists_4.png" /> cyclists'
            });
var format_Alcohol_Involvement_5 = new ol.format.GeoJSON();
var features_Alcohol_Involvement_5 = format_Alcohol_Involvement_5.readFeatures(json_Alcohol_Involvement_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Alcohol_Involvement_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Alcohol_Involvement_5.addFeatures(features_Alcohol_Involvement_5);
var lyr_Alcohol_Involvement_5 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Alcohol_Involvement_5, 
                style: style_Alcohol_Involvement_5,
                interactive: true,
                title: '<img src="styles/legend/Alcohol_Involvement_5.png" /> Alcohol_Involvement'
            });
var format_serverity_6 = new ol.format.GeoJSON();
var features_serverity_6 = format_serverity_6.readFeatures(json_serverity_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_serverity_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_serverity_6.addFeatures(features_serverity_6);
var lyr_serverity_6 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_serverity_6, 
                style: style_serverity_6,
                interactive: true,
                title: '<img src="styles/legend/serverity_6.png" /> serverity'
            });

lyr_OpenStreetMap_0.setVisible(true);lyr_Heatmap_1.setVisible(true);lyr_all_accidents_lon_lat__2.setVisible(true);lyr_pedestrians_3.setVisible(true);lyr_cyclists_4.setVisible(true);lyr_Alcohol_Involvement_5.setVisible(true);lyr_serverity_6.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,lyr_Heatmap_1,lyr_all_accidents_lon_lat__2,lyr_pedestrians_3,lyr_cyclists_4,lyr_Alcohol_Involvement_5,lyr_serverity_6];
lyr_all_accidents_lon_lat__2.set('fieldAliases', {'longitude': 'longitude', 'latitude': 'latitude', });
lyr_pedestrians_3.set('fieldAliases', {'latitude': 'latitude', 'longitude': 'longitude', 'pedestrians': 'pedestrians', });
lyr_cyclists_4.set('fieldAliases', {'latitude': 'latitude', 'longitude': 'longitude', 'cyclists': 'cyclists', });
lyr_Alcohol_Involvement_5.set('fieldAliases', {'longitude': 'longitude', 'latitude': 'latitude', });
lyr_serverity_6.set('fieldAliases', {'LATITUDE': 'LATITUDE', 'LONGITUDE': 'LONGITUDE', 'injured': 'injured', 'killed': 'killed', 'pedestrians': 'pedestrians', 'cyclists': 'cyclists', 'crash_severity': 'crash_severity', });
lyr_all_accidents_lon_lat__2.set('fieldImages', {'longitude': 'TextEdit', 'latitude': 'Range', });
lyr_pedestrians_3.set('fieldImages', {'latitude': 'TextEdit', 'longitude': 'TextEdit', 'pedestrians': 'Range', });
lyr_cyclists_4.set('fieldImages', {'latitude': 'TextEdit', 'longitude': 'TextEdit', 'cyclists': 'Range', });
lyr_Alcohol_Involvement_5.set('fieldImages', {'longitude': 'TextEdit', 'latitude': 'TextEdit', });
lyr_serverity_6.set('fieldImages', {'LATITUDE': 'TextEdit', 'LONGITUDE': 'TextEdit', 'injured': 'Range', 'killed': 'CheckBox', 'pedestrians': 'Range', 'cyclists': 'CheckBox', 'crash_severity': 'Range', });
lyr_all_accidents_lon_lat__2.set('fieldLabels', {'longitude': 'no label', 'latitude': 'no label', });
lyr_pedestrians_3.set('fieldLabels', {'latitude': 'no label', 'longitude': 'no label', 'pedestrians': 'no label', });
lyr_cyclists_4.set('fieldLabels', {'latitude': 'no label', 'longitude': 'no label', 'cyclists': 'no label', });
lyr_Alcohol_Involvement_5.set('fieldLabels', {'longitude': 'no label', 'latitude': 'no label', });
lyr_serverity_6.set('fieldLabels', {'LATITUDE': 'no label', 'LONGITUDE': 'no label', 'injured': 'header label', 'killed': 'header label', 'pedestrians': 'no label', 'cyclists': 'header label', 'crash_severity': 'header label', });
lyr_serverity_6.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});